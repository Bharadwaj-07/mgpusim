# rm -rf private;
# rm -rf shared;
# rm -rf mgvm;
# rm -rf mgvm-nobalance;

rm -rf normal;
rm -rf l1-prefetcher;
rm -rf l2-prefetcher;
rm -rf combined;
rm -rf infinite-l2;
